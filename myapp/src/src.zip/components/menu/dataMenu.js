const dataMenu = [
  {
    id: "catalog",
    name: "Каталог",
    link: "#catalog",
  },
  {
    id: "blog",
    name: "Блог",
    link: "#blog",
  },
  {
    id: "faq",
    name: "FAQ",
    link: "#faq",
  },
  {
    id: "about",
    name: "О нас",
    link: "#about",
  },
  {
    id: "contacts",
    name: "Контакты",
    link: "#contacts",
  },
];

export default dataMenu;
